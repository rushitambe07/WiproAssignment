package com.wipro.servicediscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicediscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
